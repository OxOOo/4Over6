package com.tinytangent.droidover6;

/**
 * Created by tansinan on 5/9/17.
 */

public class BackendIPC {
    static int BACKEND_STATE_CONNECTING = 0;
    static int BACKEND_STATE_WAITING_FOR_IP_CONFIGURATION = 1;
    static int BACKEND_STATE_CONNECTED = 2;
    static int BACKEND_STATE_DISCONNECTED = 3;
}
